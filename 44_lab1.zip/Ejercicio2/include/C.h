#ifndef C_h
#define C_h
#include "../include/B.h"
#include "../include/A.h"

class A;
class B;

class C {
private:
     B * b;
	 A * a;
}; 
#endif
