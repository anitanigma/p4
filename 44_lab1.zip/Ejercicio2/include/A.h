#ifndef A_h
#define A_h
#include "../include/B.h"
#include "../include/C.h"

class B;
class C;

class A {
private:
     B * b;
	 C * c;
}; 
#endif
