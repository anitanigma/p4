#ifndef B_h
#define B_h
#include "../include/C.h"
#include "../include/A.h"

class A;
class C;

class B {
private:
     C * c;
	 A * a;
}; 
#endif
